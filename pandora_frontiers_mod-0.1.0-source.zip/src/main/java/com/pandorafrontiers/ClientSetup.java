package com.pandorafrontiers;

import com.pandorafrontiers.client.model.IkranModel;
import com.pandorafrontiers.entity.IkranEntity;
import com.pandorafrontiers.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PandoraFrontiers.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    public static final ModelLayerLocation IKran_LAYER = new ModelLayerLocation(new ResourceLocation(PandoraFrontiers.MOD_ID, "ikran"), "main");

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(IKran_LAYER, IkranModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.IKRAN.get(), context ->
                new MobRenderer<IkranEntity, IkranModel>(context, new IkranModel(context.bakeLayer(IKran_LAYER)), 0.85f) {
                    @Override public ResourceLocation getTextureLocation(IkranEntity entity) {
                        return new ResourceLocation(PandoraFrontiers.MOD_ID, "textures/entity/ikran.png");
                    }
                });
    }
}
