package com.pandorafrontiers;

import com.pandorafrontiers.entity.IkranEntity;
import com.pandorafrontiers.registry.ModEntities;
import com.pandorafrontiers.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PandoraFrontiers.MOD_ID)
public class PandoraFrontiers {
    public static final String MOD_ID = "pandora_frontiers";

    public PandoraFrontiers() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        MinecraftForge.EVENT_BUS.register(this);
    }

    public static void chooseFaction(Player player, boolean navi) {
        player.getPersistentData().putString("pandora_faction", navi ? "navi" : "human");
        player.displayClientMessage(Component.literal(navi ?
                "§bВы выбрали сторону На'ви. Эйва ведёт тебя." :
                "§eВы выбрали сторону людей. Технологии помогут вам."), true);
    }

    public static String faction(Player player) {
        return player.getPersistentData().getString("pandora_faction");
    }
}
