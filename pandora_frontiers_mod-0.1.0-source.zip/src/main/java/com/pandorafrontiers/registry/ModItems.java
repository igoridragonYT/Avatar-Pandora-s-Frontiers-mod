package com.pandorafrontiers.registry;

import com.pandorafrontiers.PandoraFrontiers;
import com.pandorafrontiers.item.FactionChoiceItem;
import com.pandorafrontiers.item.TsaheyluItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PandoraFrontiers.MOD_ID);
    public static final RegistryObject<Item> NAVI_CHOICE = ITEMS.register("navi_choice", () -> new FactionChoiceItem(true, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HUMAN_CHOICE = ITEMS.register("human_choice", () -> new FactionChoiceItem(false, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> TSAHEYLU = ITEMS.register("tsaheylu", () -> new TsaheyluItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> IKRAN_ROPE = ITEMS.register("ikran_rope", () -> new Item(new Item.Properties().stacksTo(16)));
}
