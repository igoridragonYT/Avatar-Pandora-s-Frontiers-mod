package com.pandorafrontiers.registry;

import com.pandorafrontiers.PandoraFrontiers;
import com.pandorafrontiers.entity.IkranEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.entity.EntityType;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PandoraFrontiers.MOD_ID);
    public static final RegistryObject<EntityType<IkranEntity>> IKRAN = ENTITIES.register("ikran", () ->
            EntityType.Builder.of(IkranEntity::new, MobCategory.CREATURE)
                    .sized(1.8f, 1.5f).clientTrackingRange(10).build("ikran"));
}
