package com.pandorafrontiers.client.model;

import com.pandorafrontiers.entity.IkranEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.util.Mth;

/** Low-poly ikran silhouette: body, beak, crest, tail, legs and four wing membranes. */
public class IkranModel extends HierarchicalModel<IkranEntity> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart tail;

    public IkranModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.leftWing = body.getChild("left_wing");
        this.rightWing = body.getChild("right_wing");
        this.tail = body.getChild("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5, -4, -9, 10, 8, 18, new CubeDeformation(0.15f)), PartPose.offset(0, 15, 0));
        body.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(0, 27).addBox(-3, -3, -5, 6, 6, 8), PartPose.offset(0, -1, -9));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(28, 27)
                .addBox(-3.5f, -4, -6, 7, 7, 7)
                .texOffs(0, 40).addBox(-2, -2, -11, 4, 3, 6), PartPose.offset(0, -3, -12));
        head.addOrReplaceChild("crest", CubeListBuilder.create().texOffs(20, 40).addBox(-1, -5, -3, 2, 5, 5), PartPose.ZERO);
        head.addOrReplaceChild("left_eye", CubeListBuilder.create().texOffs(28, 42).addBox(-4, -2, -4, 1, 2, 2), PartPose.ZERO);
        head.addOrReplaceChild("right_eye", CubeListBuilder.create().texOffs(28, 42).addBox(3, -2, -4, 1, 2, 2), PartPose.ZERO);
        body.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(38, 0).addBox(-2, -2, 0, 4, 4, 15), PartPose.offset(0, 0, 8));
        body.addOrReplaceChild("left_wing", CubeListBuilder.create().texOffs(0, 48).addBox(0, -1, -5, 16, 2, 10), PartPose.offset(4, -1, -3));
        body.addOrReplaceChild("right_wing", CubeListBuilder.create().texOffs(0, 48).mirror().addBox(-16, -1, -5, 16, 2, 10), PartPose.offset(-4, -1, -3));
        body.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(38, 20).addBox(-1, 0, -2, 2, 7, 3), PartPose.offset(3, 3, -5));
        body.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(38, 20).addBox(-1, 0, -2, 2, 7, 3), PartPose.offset(-3, 3, -5));
        body.addOrReplaceChild("left_rear_leg", CubeListBuilder.create().texOffs(48, 20).addBox(-1, 0, -2, 2, 6, 3), PartPose.offset(3, 3, 5));
        body.addOrReplaceChild("right_rear_leg", CubeListBuilder.create().texOffs(48, 20).addBox(-1, 0, -2, 2, 6, 3), PartPose.offset(-3, 3, 5));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override public ModelPart root() { return root; }

    @Override public void setupAnim(IkranEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float)Math.PI / 180F) * 0.55f;
        head.xRot = headPitch * ((float)Math.PI / 180F) * 0.35f;
        float flap = Mth.sin(ageInTicks * 0.55f) * 0.28f;
        if (entity.isVehicle()) flap *= 1.8f;
        leftWing.zRot = -0.18f - flap;
        rightWing.zRot = 0.18f + flap;
        tail.xRot = Mth.cos(limbSwing * 0.45f) * limbSwingAmount * 0.12f;
    }
}
