package com.pandorafrontiers.item;

import com.pandorafrontiers.PandoraFrontiers;
import com.pandorafrontiers.entity.IkranEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

public class TsaheyluItem extends Item {
    public TsaheyluItem(Properties properties) { super(properties); }
    @Override public InteractionResult useOn(UseOnContext context) {
        if (!(context.getPlayer() != null)) return InteractionResult.PASS;
        Entity target = context.getLevel().getEntitiesOfClass(IkranEntity.class, new net.minecraft.world.phys.AABB(context.getClickLocation(), context.getClickLocation()).inflate(2.5), e -> true)
                .stream().findFirst().orElse(null);
        if (target instanceof IkranEntity ikran && !context.getLevel().isClientSide) {
            Player player = context.getPlayer();
            if ("navi".equals(PandoraFrontiers.faction(player)) && ikran.isTame()) {
                ikran.setBonded(true);
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§dЦахейлу установлена: связь с икраном создана!"), true);
                return InteractionResult.CONSUME;
            }
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("§cНужен выбранный путь На'ви и приручённый икран."), true);
            return InteractionResult.FAIL;
        }
        return InteractionResult.PASS;
    }
}
