package com.pandorafrontiers.item;

import com.pandorafrontiers.PandoraFrontiers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FactionChoiceItem extends Item {
    private final boolean navi;
    public FactionChoiceItem(boolean navi, Properties properties) { super(properties); this.navi = navi; }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) PandoraFrontiers.chooseFaction(player, navi);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
