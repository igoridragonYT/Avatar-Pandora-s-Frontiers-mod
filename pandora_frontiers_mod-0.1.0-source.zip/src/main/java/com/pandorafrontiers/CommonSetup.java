package com.pandorafrontiers;

import com.pandorafrontiers.entity.IkranEntity;
import com.pandorafrontiers.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PandoraFrontiers.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class CommonSetup {
    @SubscribeEvent public static void attributes(EntityAttributeCreationEvent event) { event.put(ModEntities.IKRAN.get(), IkranEntity.createAttributes().build()); }
}
