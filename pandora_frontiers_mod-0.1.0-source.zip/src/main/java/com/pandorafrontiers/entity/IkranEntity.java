package com.pandorafrontiers.entity;

import com.pandorafrontiers.PandoraFrontiers;
import com.pandorafrontiers.registry.ModEntities;
import com.pandorafrontiers.registry.ModItems;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class IkranEntity extends TamableAnimal {
    private static final EntityDataAccessor<Boolean> BONDED = SynchedEntityData.defineId(IkranEntity.class, EntityDataSerializers.BOOLEAN);
    public IkranEntity(EntityType<? extends TamableAnimal> type, Level level) { super(type, level); }
    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.createLivingAttributes().add(Attributes.MAX_HEALTH, 40).add(Attributes.MOVEMENT_SPEED, 0.30).add(Attributes.FLYING_SPEED, 0.32).add(Attributes.ATTACK_DAMAGE, 5);
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        goalSelector.addGoal(2, new FollowOwnerGoal(this, 1.15, 4, 16, false));
    }
    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(BONDED, false); }
    public boolean isBonded() { return entityData.get(BONDED); }
    public void setBonded(boolean bonded) { entityData.set(BONDED, bonded); }
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!isTame() && held.is(ModItems.IKRAN_ROPE.get())) {
            if (!level().isClientSide) { tame(player); held.shrink(1); player.displayClientMessage(net.minecraft.network.chat.Component.literal("§aИкран приручён. Теперь установите цахейлу!"), true); }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (isTame() && isBonded() && held.isEmpty() && !player.isShiftKeyDown()) {
            if (!level().isClientSide) player.startRiding(this);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (isTame() && isOwnedBy(player) && player.isShiftKeyDown()) {
            setOrderedToSit(!isOrderedToSit());
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }
    @Override public void travel(net.minecraft.world.phys.Vec3 travelVector) {
        if (isVehicle() && getControllingPassenger() instanceof Player player && isBonded()) {
            setYRot(player.getYRot()); yRotO = getYRot();
            setXRot(player.getXRot() * 0.5f); xRotO = getXRot();
            float forward = player.zza; float strafe = player.xxa;
            setSpeed((float)getAttributeValue(Attributes.MOVEMENT_SPEED)); super.travel(new net.minecraft.world.phys.Vec3(strafe, player.isSprinting() ? 0.1 : 0, forward));
        } else super.travel(travelVector);
    }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) { return ModEntities.IKRAN.get().create(level); }
}
